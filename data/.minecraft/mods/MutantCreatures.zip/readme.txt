<<Mutant Creatures Mod>>
by thehippomaster21

The Mutant Creatures Mod is a mod that adds a few fully-animated mini-bosses that are essentially stronger and mutated
versions of the original minecraft mobs. Each mob has a special death and/or drop. This also adds Chemical X, which
can be crafted and thrown and mobs to make them become mutated.



Installation
To install the mod, first install Minecraft Forge, which can be found at: http://files.minecraftforge.net/
Then, simply move the whole UNEXTRACTED mod zip file into the .minecraft/mods folder. If there is no 'mods' folder,
simply create a new one in the .minecraft directory.



Changelist
v1.4.2:
~fixed skeleton helmet crashing without skeleton chest armor
~fixed another server issue with the endersoul hand