package mekanism.api;

public final class ObfuscatedNames
{
	public static String[] Minecraft_timer = new String[] {"timer", "field_71428_T", "S"};
	public static String[] GuiContainer_xSize = new String[] {"xSize", "field_146999_f", "c"};
	public static String[] GuiContainer_ySize = new String[] {"ySize", "field_147000_g", "d"};
	public static String[] GuiContainer_guiLeft = new String[] {"guiLeft", "field_147003_i"};
	public static String[] GuiContainer_guiTop = new String[] {"guiTop", "field_147009_r"};
	public static String[] NetHandlerPlayServer_floatingTickCount = new String[] {"floatingTickCount", "field_147365_f"};
	public static String[] SoundHandler_sndManager = new String[] {"sndManager", "field_147694_f"};
	public static String[] SoundManager_sndSystem = new String[] {"sndSystem", "field_148620_e"};
	public static String[] SoundManager_invPlayingSounds = new String[] {"invPlayingSounds", "field_148630_i"};
	public static String[] AbstractClientPlayer_getPlayerInfo = new String[] {"getPlayerInfo", "func_175155_b"};
	public static String[] NetworkPlayerInfo_playerTextures = new String[] {"playerTextures", "field_187107_a"};
	public static String[] Entity_copyDataFromOld = new String[] {"copyDataFromOld", "func_180432_n"};
	public static String[] VertexBuffer_isDrawing = new String[] {"isDrawing", "field_179010_r"};
}