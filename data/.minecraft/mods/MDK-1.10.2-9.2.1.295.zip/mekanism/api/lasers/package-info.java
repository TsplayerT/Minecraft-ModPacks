@API(apiVersion = "9.0.0", owner = "Mekanism", provides = "MekanismAPI|laser")
package mekanism.api.lasers;
import net.minecraftforge.fml.common.API;

