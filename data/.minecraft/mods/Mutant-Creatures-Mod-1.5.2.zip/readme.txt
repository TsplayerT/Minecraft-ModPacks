<<Mutant Creatures Mod>>
by thehippomaster21

The Mutant Creatures Mod is a mod that adds a few fully-animated mini-bosses that are essentially stronger and mutated
versions of the original minecraft mobs. Each mob has a special death and/or drop. This also adds Chemical X, which
can be crafted and thrown and mobs to make them become mutated.



Installation
To install the mod, first install Minecraft Forge, which can be found at: http://files.minecraftforge.net/
Then, simply move the whole UNEXTRACTED mod zip file into the .minecraft/mods folder. If there is no 'mods' folder,
simply create a new one in the .minecraft directory.



Changelist
v1.3.4:
~updated to mc1.5.2
~added a bit of code for mutant skeleton
~added mutant zombie villagers, spawning with a 1/8 chance for each mutant zombie spawn
~made mutant zombie villager spawn more zombie villagers when roaring
~made mobs attacking the mutant enderman stop attacking when the mutant enderman uses its clone attack
~re-implemented spawn eggs for more compatibility with forge
~made creeper minions spawned from spawn eggs tamed
~completely changed entity IDs to use only forge IDs; THIS UPDATE WILL NOT WORK WITH OLD UPDATES
~removed entity id section in configuration; there should be no more entity id conflicts
~moved the files around to make things more organized
~stopped mutant creatures from spawning in biomes from other mods
~made mutant zombie and mutant enderman animation transitions a bit smoother
